# Workshop Django & React

## Django

### Initial commands

```
python --version 
pip --version 

pip install virtualenv
python -m venv venv 
venv\Scripts\activate

pip install django
pip install djangorestframework
django-admin startproject backend
```

### Install Django

```
pip install django
pip install djangorestframework
django-admin startproject backend
```

In `setting.py` file add:

```
# Application definition

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework'
]

```

In path `backend` folder (1st), run the command:
```
python manage.py startapp api
```

In `setting.py` file add tha api app:

```
# Application definition

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'api'
]

```

Create `urls.py` file in `api` folder. This file will connect the views to the routes

In `backend/backend/urls.py` add:
```
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('api.urls'))
]

```

In `backend/api/views.py` add:
```
from rest_framework.views import APIView
from rest_framework.response import Response

class BaseView(APIView):
    def get(self, request):
        return Response("Hello World")
```

In `backend/api/urls.py` add:
```
from django.urls import path
from .views import BaseView 

urlpatterns = [
    path('', BaseView.as_view())
]
```

Run `python manage.py runserver`

In `backend/api/models.py` add:
```
from django.db import models

class Task(models.Model):
    name = models.CharField(max_length=20)
    description = models.TextField(max_length=100)
    due_to = models.DateTimeField(blank=True, auto_now=False)
    is_completed = models.BooleanField()

    def __str__(self):
        return self.name
```

Run:

```
python manage.py makemigrations
python manage.py migrate

```

Run:

```
python manage.py createsuperuser
```

In `backend/api/admin.py` add:
```
from django.contrib import admin
from .models import Task

# Register your models here.
admin.site.register(Task)
```

Creating serializers: new file called `api/serializers.py`
```
from rest_framework import serializers
from .models from Task

class TaskSerializer(serializers.ModelSerializer):
    class Meta:
        model = Task 
        fields = '__all__'
```

Create views in `backend/api/views.py`

Add urls in `backend/api/urls.py`

```
from django.urls import path
from .views import BaseView, TaskView, SingleTaskView 

urlpatterns = [
    # path('', BaseView.as_view())
    path('tasks', TaskView.as_view()), #Para o endpoint http://127.0.0.1:8000/api/tasks
    path('tasks/<id>', SingleTaskView.as_view()) #Para o endpoint http://127.0.0.1:8000/api/<id>
]
```